#include "board.h"

using namespace std;

// main function that initializes a game board and executes methods for testing
int main() {

  // Sudoku 4b, most up-to-date testing
  board myBoard;

  //--------------------------------------

  // previous testing
  /*board board1;
  int numcalls = board1.solve();
  board1.printBoard();
  if (board1.isSolved()) {
    cout << "board 1 is solved in " << numcalls << " calls!\n";
  }
  else {
    cout << "failed to solve board!!\n";
  }
  board board2;
  numcalls = board2.solve();
  board2.printBoard();
  if (board2.isSolved()) {
    cout << "board 2 is solved in " << numcalls << " calls!\n";
  }
  else {
    cout << "failed to solve board!!\n";
  }
  board board3;
  numcalls = board3.solve();
  board3.printBoard();
  if (board3.isSolved()) {
    cout << "board 3 is solved in " << numcalls << " calls!\n";
  }
  else {
    cout << "failed to solve board!!\n";
  }*/
}